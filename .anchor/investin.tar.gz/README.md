# Investin's Mango Market Making Funds


![version](https://img.shields.io/badge/version-1.1.0-blue.svg) ![license](https://img.shields.io/badge/license-MIT-blue.svg) [![GitHub issues open](https://img.shields.io/github/issues/creativetimofficial/black-dashboard-react.svg?maxAge=2592000)]() [![GitHub issues closed](https://img.shields.io/github/issues-closed-raw/creativetimofficial/black-dashboard-react.svg?maxAge=2592000)]()  [![Chat](https://img.shields.io/badge/chat-on%20discord-7289da.svg)](https://discord.com/invite/Yf54h9B)

![logoWithHeading](https://assets.coingecko.com/coins/images/15588/small/ivn_logo.png)

# Overview
Investin's Mango Market Making Funds empower MMs with the ability to run a pooled investment fund


#### build
```bash
$ npm run build:program
```

#### run basic UI

```bash
$ cd frontend/
$ yarn
$ yarn start
```

